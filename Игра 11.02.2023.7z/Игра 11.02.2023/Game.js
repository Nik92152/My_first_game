// Переменные 
let righPosition = 0;
let imgblockposition = 0;
let direction = "right";
let hitAction = "false";
let jumpAction = "false";
let timer = null;
let x = 0;
let halfwidth = window.screen.width / 2;

let heroImg = window.document.querySelector("#hero-img");   
let jumpBlock =window.document.querySelector("#jump");
let hitBlock =window.document.querySelector("#hit");
let imgBlock = window.document.querySelector("#img-block");

let canvas = window.document.querySelector("#canvas");
let FullcsreenButton = window.document.querySelector("#Fullcscreen");

jumpBlock.style.top = `${window.screen.height/2 - 145}px`;
hitBlock.style.top = `${window.screen.height/2 - 145}px`;

jumpBlock.onclick =() => {jumpAction = true} ;
hitBlock.onclick =() => {hitAction = true} ;

    heroImg.onclick = (event) => {
        event.preventDefault();
    }
    FullcsreenButton.onclick = () => {
        if (document.fullscreenElement ){
            document.exitFullscreen();
            Fullcscreen.src = "img/fullscreen.png";
        } else{
            Fullcscreen.src = "img/close.png";
            canvas.requestFullscreen();

        }
    }
    jumpAction.onclick = () => {jumpAction = true};
    hitAction.onclick = () => {hitAction = true}; 
    
    //  Функции
    const rigthHandler = () => {
heroImg.style.transform = "scale(1,1)";
righPosition = righPosition + 1;
imgblockposition = imgblockposition + 1;
if (righPosition > 4) {
    righPosition = 0;
}
heroImg.style.left = `-${righPosition * 125}px`;
heroImg.style.top = "-150px";
imgBlock.style.left = `${imgblockposition*30}px`;
}

const leftHandler = () => {
    heroImg.style.transform = "scale(-1,1)";
    righPosition = righPosition + 1;
    imgblockposition = imgblockposition - 1;
    if (righPosition > 4) {
        righPosition = 0;
    }
    heroImg.style.left = `-${righPosition * 135}px`;
    heroImg.style.top = "-150px";
    imgBlock.style.left = `${imgblockposition*30}px`;
    }

    const standHandler = () => {
    
    switch(direction){
        case "right": {
            heroImg.style.transform = "scale(1,1)";
            if (righPosition > 2) {
                righPosition = 1;
            }
            break;
        }
        case "left": {
            heroImg.style.transform = "scale(-1,1)";
            if (righPosition > 2) {
                righPosition = 0;
            }
            break;
        }
        default: break; 
    }

    righPosition = righPosition + 1;
    heroImg.style.left = `-${righPosition * 130}px`;
    heroImg.style.top = "0px";
}     

const hitHandler =() => {
    
    switch(direction){
        case "right": {
            heroImg.style.transform = "scale(1,1)";
            if (righPosition > 2 ) {
                righPosition = 1;
                hitAction = false;
            }
            break;
        }
        case "left": {
            heroImg.style.transform = "scale(-1,1)";
            if (righPosition > 2) {
                righPosition = 0;
                hitAction = false;
            }
            break;
        }
        default: break; 
    }

    righPosition = righPosition + 1;
    heroImg.style.left = `-${righPosition * 130}px`;
    heroImg.style.top = "0px";
} 
    
const jumpHandler =() => {
    
    switch(direction){
        case "right": {
            heroImg.style.transform = "scale(1,1)";
            if (righPosition > 2 ) {
                righPosition = 1;
                jumpAction = false;
            }
            break;
        }
        case "left": {
            heroImg.style.transform = "scale(-1,1)";
            if (righPosition > 2) {
                righPosition = 0;
                jumpAction = false;
            }
            break;
        }
        default: break; 
    }

    righPosition = righPosition + 1;
    heroImg.style.left = `-${righPosition * 130}px`;
    heroImg.style.top = "-50px";
} 


// Обработчики событий

let ontouchstart = (event) => {
    clearInterval(timer);
    // event.preventDefault();
    
    if (event.type === "mousedown"){
        x = event.screenX;
    } else {
        x = event.touches[0].screenX;
    }
    
    timer = setInterval( () => {
     if( x > halfwidth  ) {
        direction = "right";
        rigthHandler();
    } else {
        direction = "left";
        leftHandler();
    } 
    
   }, 200);
}
    
let ontouchend = (event) => {
    // event.preventDefault();
    clearInterval(timer);
    lifecircle();
}


window.onmousedown = ontouchstart;

window.ontouchstart = ontouchstart;

window.onmouseup = ontouchend;

window.ontouchend = ontouchend; 

const lifecircle = () => {
    timer = setInterval( () => {
        if (hit){
            hitHandler();
        } else if (jump){
            jumpHandler();

        } else {
        
        standHandler();
        }
        
    }, 200);
}
const start = () =>{
    lifecircle();
}
start();